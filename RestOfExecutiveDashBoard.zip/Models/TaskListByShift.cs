﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public class TaskListByShift
    {
        public int TaskListByShiftId { get; set; }
        public int? TaskDetailsId { get; set; }
        public DateTime TaskDate { get; set; }
        public string TaskName { get; set; }
        public string ApplicationName { get; set; }
        public string ActionedBy { get; set; }
        public DateTime? ActionedTime { get; set; }
        public bool? IsSuccess { get; set; }
        public bool? IsException { get; set; }
        public string IncidentNumber { get; set; }
        public bool? IsMailSent { get; set; }
        public DateTime ScheduledStartTime { get; set; }
        public DateTime ScheduledEndTime { get; set; }
        public int ApplicationDetailsId { get; set; }
        public int ShiftDetailsId { get; set; }
        public string IncidentDescription { get; set; }
        public string IncidentTitle { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime IncidentStartTime { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime IncidentEndTime { get; set; }

        //public string IncidentStartTime { get; set; }
        //public string IncidentEndTime { get; set; }

        public int? IncidentTypeDetailsId { get; set; }




        public TaskDetails TaskDetails { get; set; }
        public ApplicationDetails ApplicationDetails { get; set; }
        public ShiftDetails ShiftDetails { get; set; }
        public IncidentTypeDetails IncidentTypeDetails { get; set; }


    }
}