﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public class AnnouncementTrackingDetails
    {
        public int AnnouncementTrackingDetailsId { get; set; }

        public int AnnouncementDetailsId { get; set; }

        [Display(Name = "Announcement Name")]
        [Required]
        public string AnnouncementName { get; set; }

        [Display(Name = "Announcement Description")]
        [Required]
        public string AnnouncementDescription { get; set; }

        [Display(Name = "Valid From")]
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime ValidFrom { get; set; }

        [Display(Name = "Valid Upto")]
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime ValidUpto { get; set; }

        public string Contact { get; set; }

        public string ReadBy { get; set; }
                
        public DateTime? ReadTime { get; set; }
        public bool IsRead { get; set; }


        public AnnouncementDetails AnnouncementDetails { get; set; }
    }
}