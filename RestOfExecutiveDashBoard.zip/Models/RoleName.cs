﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public static class RoleName
    {
        public const string CanManageTasks = "CanManageTasks";
    }
}