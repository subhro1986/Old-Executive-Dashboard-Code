﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public class MailConfigDetails
    {
            public int MailConfigDetailsId { get; set; }
            public int ApplicationDetailsId { get; set; }
            public int IncidentTypeDetailsId { get; set; }
            public string MailTo { get; set; }
            public string MailCC { get; set; }
            public string Subject { get; set; }
            public string Body { get; set; }

            public ApplicationDetails ApplicationDetails { get; set; }
            public IncidentTypeDetails IncidentTypeDetails { get; set; }


    }
}