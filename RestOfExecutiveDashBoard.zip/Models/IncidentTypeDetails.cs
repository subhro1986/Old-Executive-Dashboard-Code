﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public class IncidentTypeDetails
    {
        public int IncidentTypeDetailsId { get; set; }
        public string IncidentTypeName { get; set; }
        public string IncidentTypeDescription { get; set; }
    }
}