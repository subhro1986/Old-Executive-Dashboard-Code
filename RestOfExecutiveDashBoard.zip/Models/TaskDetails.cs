﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.AccessControl;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public class TaskDetails
    {
        public int TaskDetailsId { get; set; }
        public string TaskName { get; set; }
        public string TaskDescription { get; set; }
        public int ApplicationDetailsId { get; set; }
        public string ApplicationName { get; set; }

        public int ShiftDetailsId { get; set; }
        //[DataType(DataType.Time)]
        //[DisplayFormat(DataFormatString = "{hh:mm tt}", ApplyFormatInEditMode = true)]
        public DateTime ScheduledStartTime { get; set; }
        //[DataType(DataType.Time)]
        //[DisplayFormat(DataFormatString = "{hh:mm tt}", ApplyFormatInEditMode = true)]
        public DateTime ScheduledEndTime { get; set; }

        public ApplicationDetails ApplicationDetails { get; set; }
        public ShiftDetails ShiftDetails { get; set; }          
    }
}