﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public class ApplicationManagerDetails
    {
        public int ApplicationManagerDetailsId { get; set; }
        public string ApplicationManagerName { get; set; }
        public string ApplicationManagerMailId { get; set; }
    }
}