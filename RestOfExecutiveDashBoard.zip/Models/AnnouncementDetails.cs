﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public class AnnouncementDetails
    {
        public int AnnouncementDetailsId { get; set; }

        [Display(Name = "Announcement Name")]
        [Required]
        public string AnnouncementName { get; set; }

        [Display(Name = "Announcement Description")]
        
        public string AnnouncementDescription { get; set; }
        [Display(Name = "Valid From")]
        
        public DateTime ValidFrom { get; set; }
        [Display(Name = "Valid Upto")]
        
        public DateTime ValidUpto { get; set; }
        public string Contact { get; set; }

    }
}