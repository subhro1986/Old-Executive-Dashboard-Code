﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public class TaskStatusDetails
    {
        public int TaskStatusDetailsId { get; set; }
        public string TaskStatusName { get; set; }
        public string TaskStatusDescription { get; set; }
    }
}