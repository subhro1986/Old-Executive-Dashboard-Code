﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public class ShiftDetails
    {
        public int ShiftDetailsId { get; set; }
        public string ShiftName { get; set; }
        public string ShiftDescription { get; set; }
    }
}