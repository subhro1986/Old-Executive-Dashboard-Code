﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Models
{
    public class ApplicationStatusDetails
    {
        public int ApplicationStatusDetailsId { get; set; }
        public string ApplicationStatusName { get; set; }
        public string ApplicationStatusDescription { get; set; }
    }
}