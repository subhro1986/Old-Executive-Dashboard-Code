﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using ExecutiveDashboard.Dtos;
using ExecutiveDashboard.Models;

namespace ExecutiveDashboard.App_Start
{
    public class MappingProfile:Profile
    {
        public MappingProfile()
        {

            Mapper.CreateMap<TaskDetails, TaskDto>();
            Mapper.CreateMap<ApplicationDetails, ApplicationDetailsDto>();
            Mapper.CreateMap<ShiftDetails, ShiftDetailsDto>();
            Mapper.CreateMap<MailConfigDetails, MailConfigDto>();
            Mapper.CreateMap<AnnouncementDetails, AnnouncementDto>();

            // Dto to Domain
            Mapper.CreateMap<TaskDto, TaskDetails>()
                .ForMember(t => t.TaskDetailsId, opt => opt.Ignore());
           

            

        }


    }
}