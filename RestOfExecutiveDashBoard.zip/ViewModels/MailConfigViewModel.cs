﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.ComponentModel.DataAnnotations;
using System.Web;
using ExecutiveDashboard.Models;

namespace ExecutiveDashboard.ViewModels
{
    public class MailConfigViewModel
    {

        public IEnumerable<ApplicationDetails> ApplicationDetails { get; set; }
        public IEnumerable<IncidentTypeDetails> IncidentTypeDetails { get; set; }


        public int MailConfigDetailsId { get; set; }
        [Display(Name = "Application")]
        [StringLength(255)]
        public int ApplicationDetailsId { get; set; }

        [Display(Name = "Incident Type")]
        [StringLength(255)]
        public int? IncidentTypeDetailsId { get; set; }

        public string MailTo { get; set; }
        public string MailCC { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }


        //public string Title
        //{
        //    get
        //    {
        //        return TaskDetailsId != 0 ? "Edit Task" : "New task";
        //    }
        //}

        public MailConfigViewModel()
        {
            MailConfigDetailsId = 0;
        }

        public MailConfigViewModel(MailConfigDetails mail)
        {
            MailConfigDetailsId = mail.MailConfigDetailsId;
            ApplicationDetailsId = mail.ApplicationDetailsId;
            IncidentTypeDetailsId = mail.IncidentTypeDetailsId;
            MailTo = mail.MailTo;
            MailCC = mail.MailCC;
            Subject = mail.Subject;
            Body = mail.Body;
        }

    }
}


