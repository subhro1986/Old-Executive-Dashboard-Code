﻿using ExecutiveDashboard.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.ViewModels
{
    public class TaskListByShiftViewModel
    {
        public IEnumerable<ApplicationDetails> ApplicationDetails { get; set; }
        public IEnumerable<ShiftDetails> ShiftDetails { get; set; }
        public IEnumerable<IncidentTypeDetails> IncidentTypeDetails { get; set; }

        public int TaskListByShiftId { get; set; }
        public string ActionedBy { get; set; }
        public DateTime? ActionedTime { get; set; }
        public bool? IsSuccess { get; set; }
        public bool? IsException { get; set; }
        public string IncidentNumber { get; set; }
        public bool IsMailSent { get; set; }
        public int? TaskDetailsId { get; set; }
        [Required]
        [StringLength(255)]
        public string TaskName { get; set; }

        [Display(Name = "Shift")]
        public int ShiftDetailsId { get; set; }

        [Display(Name = "Application")]
        [StringLength(255)]
        public int ApplicationDetailsId { get; set; }

        [Required]
        [StringLength(255)]
        public string ApplicationName { get; set; }

        [Required]
        [StringLength(255)]
        public string IncidentDescription { get; set; }
        [Required]
        [StringLength(255)]
        public string IncidentTitle { get; set; }
        public DateTime? IncidentStartTime { get; set; }
        public DateTime? IncidentEndTime { get; set; }

        [Display(Name = "Incident Type")]
        [StringLength(255)]
        public int? IncidentTypeDetailsId { get; set; }

        [Required]
        [StringLength(255)]
        public string IncidentTypeName { get; set; }


        public string Title
        {
            get
            {
                return TaskDetailsId != 0 ? "Edit Incident" : "New Incident";
            }
        }

        public TaskListByShiftViewModel()
        {
            TaskDetailsId = 0;
        }

        public TaskListByShiftViewModel(TaskListByShift task)
        {
            TaskListByShiftId = task.TaskListByShiftId;
            TaskDetailsId = task.TaskDetailsId;
            TaskName = task.TaskName;
            ActionedBy = task.ActionedBy;
            ActionedTime = task.ActionedTime;
            ApplicationDetailsId = task.ApplicationDetailsId;
            ShiftDetailsId = task.ShiftDetailsId;
            IsException = task.IsException;
            IsSuccess = task.IsSuccess;
            IncidentDescription = task.IncidentDescription;
            IncidentNumber = task.IncidentNumber;
            ApplicationName = task.ApplicationName;
            IncidentTypeDetailsId = task.IncidentTypeDetailsId;
            IncidentTitle = task.IncidentTitle;
           
        }

    }
}
