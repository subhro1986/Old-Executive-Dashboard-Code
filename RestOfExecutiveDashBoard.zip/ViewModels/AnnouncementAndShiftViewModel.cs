﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.ComponentModel.DataAnnotations;
using System.Web;
using ExecutiveDashboard.Models;

namespace ExecutiveDashboard.ViewModels
{
    public class AnnouncementAndShiftViewModel
    {

        
        public IEnumerable<ShiftDetails> ShiftDetails { get; set; }


        public int? AnnouncementDetailsId { get; set; }

        [Required]
        [StringLength(255)]
        public string AnnouncementName { get; set; }

        [Required]
        [StringLength(255)]
        public string AnnouncementDescription { get; set; }

        [Display(Name = "Shift")]

        public int ShiftDetailsId { get; set; }

        [Required]
        [StringLength(255)]
        public string ShiftName { get; set; }

        [Required]
        [StringLength(255)]
        public string ShiftDescription { get; set; }

        [Display(Name = "Valid From")]
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime ValidFrom { get; set; }

        [Display(Name = "Valid Upto")]
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime ValidUpto { get; set; }

        public string Contact { get; set; }

        //public string Title
        //{
        //    get
        //    {
        //        return TaskDetailsId != 0 ? "Edit Task" : "New task";
        //    }
        //}

        //public TaskFormViewModel()
        //{
        //    TaskDetailsId = 0;
        //}

        //public AnnouncementAndShiftViewModel(TaskDetails task)
        //{
        //    TaskDetailsId = task.TaskDetailsId;
        //    TaskName = task.TaskName;
        //    TaskDescription = task.TaskDescription;
        //    ScheduledStartTime = task.ScheduledStartTime;
        //    ScheduledEndTime = task.ScheduledEndTime;
        //    ApplicationDetailsId = task.ApplicationDetailsId;
        //    ApplicationName = task.ApplicationName;
        //    ShiftDetailsId = task.ShiftDetailsId;
        //}

    }
}


