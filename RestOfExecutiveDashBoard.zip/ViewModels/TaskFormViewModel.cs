﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.ComponentModel.DataAnnotations;
using System.Web;
using ExecutiveDashboard.Models;

namespace ExecutiveDashboard.ViewModels
{
    public class TaskFormViewModel
    {

        public IEnumerable<ApplicationDetails> ApplicationDetails { get; set; }
        public IEnumerable<ShiftDetails> ShiftDetails { get; set; }


        public int? TaskDetailsId { get; set; }

        [Required]
        [StringLength(255)]
        public string TaskName { get; set; }

        [Required]
        [StringLength(255)]
        public string TaskDescription { get; set; }

        [Display(Name = "Shift")]

        public int ShiftDetailsId { get; set; }

        [Display(Name = "Start Time")]
        [Required]
        
        public DateTime ScheduledStartTime { get; set; }

        [Display(Name = "End Time")]
        [Required]
        
        public DateTime ScheduledEndTime { get; set; }

        [Display(Name = "Application")]
        [StringLength(255)]
        public int ApplicationDetailsId { get; set; }

        [Required]
        [StringLength(255)]
        public string ApplicationName { get; set; }

        public string Title
        {
            get
            {
                return TaskDetailsId != 0 ? "Edit Task" : "New task";
            }
        }

        public TaskFormViewModel()
        {
            TaskDetailsId = 0;
        }

        public TaskFormViewModel(TaskDetails task)
        {
            TaskDetailsId = task.TaskDetailsId;
            TaskName = task.TaskName;
            TaskDescription = task.TaskDescription;
            ScheduledStartTime = task.ScheduledStartTime;
            ScheduledEndTime = task.ScheduledEndTime;
            ApplicationDetailsId = task.ApplicationDetailsId;
            ApplicationName = task.ApplicationName;
            ShiftDetailsId = task.ShiftDetailsId;
        }

    }
}


