﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.ComponentModel.DataAnnotations;
using System.Web;
using ExecutiveDashboard.Models;

namespace ExecutiveDashboard.ViewModels
{
    public class ApplicationFormViewModel
    {

        public IEnumerable<ApplicationStatusDetails> ApplicationStatusDetails { get; set; }
        public IEnumerable<ApplicationManagerDetails> ApplicationManagerDetails { get; set; }


        public int ApplicationDetailsId { get; set; }

        [Required]
        [StringLength(255)]
        public string ApplicationName { get; set; }

        [Required]
        [StringLength(255)]
        public string ApplicationCode { get; set; }

        [Required]
        [StringLength(255)]
        public string ApplicationDescription { get; set; }

        [Required]
        [Display(Name = "Manager")]
        public int ApplicationManagerDetailsId { get; set; }

        [Required]
        [Display(Name = "Status")]
        public int ApplicationStatusDetailsId { get; set; }


        [Required]
        [StringLength(255)]
        public string ApplicationL2MailId { get; set; }

        [Required]
        [StringLength(255)]
        public string ApplicationL3MailId { get; set; }

        
        public string Title
        {
            get
            {
                return ApplicationDetailsId != 0 ? "Edit Application" : "New Application";
            }
        }

        public ApplicationFormViewModel()
        {
            ApplicationDetailsId = 0;
        }

        public ApplicationFormViewModel(ApplicationDetails app)
        {
            ApplicationDetailsId = app.ApplicationDetailsId;
            ApplicationName = app.ApplicationName;
            ApplicationCode = app.ApplicationCode;
            ApplicationDescription = app.ApplicationDescription;
            ApplicationManagerDetailsId = app.ApplicationManagerDetailsId;
            ApplicationStatusDetailsId = app.ApplicationStatusDetailsId;
            ApplicationL2MailId = app.ApplicationL2MailId;
            ApplicationL3MailId = app.ApplicationL3MailId;
            
        }

    }
}


