namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateApplicationRelatedTableStructure : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.ApplicationManagerDetails", "ApplicationManagerMailId", c => c.String());
            DropColumn("dbo.ApplicationDetails", "ApplicationManagerMailId");
            DropColumn("dbo.ApplicationManagerDetails", "ApplicationManagerDescription");
        }
        
        public override void Down()
        {
            AddColumn("dbo.ApplicationManagerDetails", "ApplicationManagerDescription", c => c.String());
            AddColumn("dbo.ApplicationDetails", "ApplicationManagerMailId", c => c.String());
            DropColumn("dbo.ApplicationManagerDetails", "ApplicationManagerMailId");
        }
    }
}
