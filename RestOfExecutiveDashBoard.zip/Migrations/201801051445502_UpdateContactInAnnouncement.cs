namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateContactInAnnouncement : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AnnouncementDetails", "Contact", c => c.String());
            DropColumn("dbo.AnnouncementDetails", "IsValid");
        }
        
        public override void Down()
        {
            AddColumn("dbo.AnnouncementDetails", "IsValid", c => c.Boolean(nullable: false));
            DropColumn("dbo.AnnouncementDetails", "Contact");
        }
    }
}
