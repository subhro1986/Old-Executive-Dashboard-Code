namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateAllScheduledStartTimeEndTime : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.TaskListByShifts", "ScheduledStartTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.TaskListByShifts", "ScheduledEndTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.TaskDetails", "ScheduledStartTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.TaskDetails", "ScheduledEndTime", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.TaskDetails", "ScheduledEndTime", c => c.String());
            AlterColumn("dbo.TaskDetails", "ScheduledStartTime", c => c.String());
            AlterColumn("dbo.TaskListByShifts", "ScheduledEndTime", c => c.String());
            AlterColumn("dbo.TaskListByShifts", "ScheduledStartTime", c => c.String());
        }
    }
}
