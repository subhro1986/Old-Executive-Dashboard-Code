namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EditStarttimeEndtimeToStringinTaskDetails : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.TaskDetails", "ScheduledStartTime", c => c.String());
            AlterColumn("dbo.TaskDetails", "ScheduledEndTime", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.TaskDetails", "ScheduledEndTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.TaskDetails", "ScheduledStartTime", c => c.DateTime(nullable: false));
        }
    }
}
