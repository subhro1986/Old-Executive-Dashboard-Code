namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddDateToTaskListByShifts : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.TaskListByShifts", "TaskDate", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.TaskListByShifts", "TaskDate");
        }
    }
}
