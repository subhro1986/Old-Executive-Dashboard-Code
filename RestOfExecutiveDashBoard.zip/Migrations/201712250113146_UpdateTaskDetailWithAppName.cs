namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateTaskDetailWithAppName : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.TaskDetails", "ApplicationName", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.TaskDetails", "ApplicationName");
        }
    }
}
