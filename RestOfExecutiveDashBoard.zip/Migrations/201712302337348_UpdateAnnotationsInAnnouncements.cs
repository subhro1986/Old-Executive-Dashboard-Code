namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateAnnotationsInAnnouncements : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.AnnouncementDetails", "AnnouncementName", c => c.String(nullable: false));
            AlterColumn("dbo.AnnouncementDetails", "AnnouncementDescription", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.AnnouncementDetails", "AnnouncementDescription", c => c.String());
            AlterColumn("dbo.AnnouncementDetails", "AnnouncementName", c => c.String());
        }
    }
}
