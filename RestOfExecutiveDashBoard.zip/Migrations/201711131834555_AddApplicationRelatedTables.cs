namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddApplicationRelatedTables : DbMigration
    {
        public override void Up()
        {
            CreateTable(
               "dbo.ApplicationDetails",
               c => new
               {
                   ApplicationDetailsId = c.Int(nullable: false, identity: true),
                   ApplicationName = c.String(),
                   ApplicationCode = c.String(),
                   ApplicationDescription = c.String(),
                   ApplicationOwnerId = c.Int(nullable: false),
               })
               .PrimaryKey(t => t.ApplicationDetailsId);
            CreateTable(
                "dbo.ApplicationManagerDetails",
                c => new
                    {
                        ApplicationManagerDetailsId = c.Int(nullable: false, identity: true),
                        ApplicationManagerName = c.String(),
                        ApplicationManagerDescription = c.String(),
                    })
                .PrimaryKey(t => t.ApplicationManagerDetailsId);
            
            CreateTable(
                "dbo.ApplicationStatusDetails",
                c => new
                    {
                        ApplicationStatusDetailsId = c.Int(nullable: false, identity: true),
                        ApplicationStatusName = c.String(),
                        ApplicationStatusDescription = c.String(),
                    })
                .PrimaryKey(t => t.ApplicationStatusDetailsId);
            
            AddColumn("dbo.ApplicationDetails", "ApplicationManagerDetailsId", c => c.Int(nullable: false));
            AddColumn("dbo.ApplicationDetails", "ApplicationStatusDetailsId", c => c.Int(nullable: false));
            AddColumn("dbo.ApplicationDetails", "ApplicationL2MailId", c => c.String());
            AddColumn("dbo.ApplicationDetails", "ApplicationL3MailId", c => c.String());
            AddColumn("dbo.ApplicationDetails", "ApplicationManagerMailId", c => c.String());
            CreateIndex("dbo.ApplicationDetails", "ApplicationManagerDetailsId");
            CreateIndex("dbo.ApplicationDetails", "ApplicationStatusDetailsId");
            AddForeignKey("dbo.ApplicationDetails", "ApplicationManagerDetailsId", "dbo.ApplicationManagerDetails", "ApplicationManagerDetailsId", cascadeDelete: true);
            AddForeignKey("dbo.ApplicationDetails", "ApplicationStatusDetailsId", "dbo.ApplicationStatusDetails", "ApplicationStatusDetailsId", cascadeDelete: true);
            DropColumn("dbo.ApplicationDetails", "ApplicationOwnerId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.ApplicationDetails", "ApplicationOwnerId", c => c.Int(nullable: false));
            DropForeignKey("dbo.ApplicationDetails", "ApplicationStatusDetailsId", "dbo.ApplicationStatusDetails");
            DropForeignKey("dbo.ApplicationDetails", "ApplicationManagerDetailsId", "dbo.ApplicationManagerDetails");
            DropIndex("dbo.ApplicationDetails", new[] { "ApplicationStatusDetailsId" });
            DropIndex("dbo.ApplicationDetails", new[] { "ApplicationManagerDetailsId" });
            DropColumn("dbo.ApplicationDetails", "ApplicationManagerMailId");
            DropColumn("dbo.ApplicationDetails", "ApplicationL3MailId");
            DropColumn("dbo.ApplicationDetails", "ApplicationL2MailId");
            DropColumn("dbo.ApplicationDetails", "ApplicationStatusDetailsId");
            DropColumn("dbo.ApplicationDetails", "ApplicationManagerDetailsId");
            DropTable("dbo.ApplicationStatusDetails");
            DropTable("dbo.ApplicationManagerDetails");
        }
    }
}
