namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateIncidentDetailsInTaskListByShift : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.TaskListByShifts", "IncidentTitle", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.TaskListByShifts", "IncidentTitle");
        }
    }
}
