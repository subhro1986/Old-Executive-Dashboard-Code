namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PopulateAlltheTables : DbMigration
    {
        public override void Up()
        {
            Sql(@"
SET IDENTITY_INSERT [dbo].[ShiftDetails] ON
INSERT INTO [dbo].[ShiftDetails] ([ShiftDetailsId], [ShiftName], [ShiftDescription]) VALUES (1, N'Shift 1', N'Morning Shift')
INSERT INTO [dbo].[ShiftDetails] ([ShiftDetailsId], [ShiftName], [ShiftDescription]) VALUES (2, N'Shift 2', N'Noon Shift')
INSERT INTO [dbo].[ShiftDetails] ([ShiftDetailsId], [ShiftName], [ShiftDescription]) VALUES (3, N'Shift 3', N'Night Shift')
SET IDENTITY_INSERT [dbo].[ShiftDetails] OFF


SET IDENTITY_INSERT [dbo].[ApplicationDetails] ON
INSERT INTO [dbo].[ApplicationDetails] ([ApplicationDetailsId], [ApplicationName], [ApplicationCode], [ApplicationDescription], [ApplicationOwnerId]) VALUES (1, N'SARE', N'RF10', N'Standardized Approach Risk Engine', 323266221)
INSERT INTO [dbo].[ApplicationDetails] ([ApplicationDetailsId], [ApplicationName], [ApplicationCode], [ApplicationDescription], [ApplicationOwnerId]) VALUES (2, N'RDL', N'R0C0', N'Risk Data Layer', 323266221)
INSERT INTO [dbo].[ApplicationDetails] ([ApplicationDetailsId], [ApplicationName], [ApplicationCode], [ApplicationDescription], [ApplicationOwnerId]) VALUES (3, N'ATOM', N'SHA0', N'Atom - Book Mapping Services', 323266221)
INSERT INTO [dbo].[ApplicationDetails] ([ApplicationDetailsId], [ApplicationName], [ApplicationCode], [ApplicationDescription], [ApplicationOwnerId]) VALUES (4, N'PE', N'YZKO', N'Projection Engine', 323266221)
SET IDENTITY_INSERT [dbo].[ApplicationDetails] OFF


SET IDENTITY_INSERT [dbo].[TaskDetails] ON
INSERT INTO [dbo].[TaskDetails] ([TaskDetailsId], [TaskName], [TaskDescription], [ApplicationDetailsId], [ScheduledStartTime], [ScheduledEndTime], [ShiftDetailsId]) VALUES (2, N'Shift 2 - Application Health Checking', N'Shift 2 - Application Health Checking', 2, N'1900-01-01 15:00:00', N'1900-01-01 15:30:00', 1)
INSERT INTO [dbo].[TaskDetails] ([TaskDetailsId], [TaskName], [TaskDescription], [ApplicationDetailsId], [ScheduledStartTime], [ScheduledEndTime], [ShiftDetailsId]) VALUES (3, N'Shift 3 - Application Health Checking', N'Shift 3 - Application Health Checking', 3, N'1900-01-01 23:00:00', N'1900-01-01 23:30:00', 2)
INSERT INTO [dbo].[TaskDetails] ([TaskDetailsId], [TaskName], [TaskDescription], [ApplicationDetailsId], [ScheduledStartTime], [ScheduledEndTime], [ShiftDetailsId]) VALUES (4, N'Shift 1 - Server Health Checking', N'Shift 1 - Server Health Checking', 1, N'1900-01-01 09:00:00', N'1900-01-01 09:30:00', 3)
INSERT INTO [dbo].[TaskDetails] ([TaskDetailsId], [TaskName], [TaskDescription], [ApplicationDetailsId], [ScheduledStartTime], [ScheduledEndTime], [ShiftDetailsId]) VALUES (5, N'Shift 2 - Server Health Checking', N'Shift 2 - Server Health Checking', 2, N'1900-01-01 15:00:00', N'1900-01-01 15:30:00', 3)
INSERT INTO [dbo].[TaskDetails] ([TaskDetailsId], [TaskName], [TaskDescription], [ApplicationDetailsId], [ScheduledStartTime], [ScheduledEndTime], [ShiftDetailsId]) VALUES (7, N'Shift 1 - Feed Availability Checking', N'Shift 1 - Feed Availability Checking', 1, N'1900-01-01 09:00:00', N'1900-01-01 09:30:00', 2)
INSERT INTO [dbo].[TaskDetails] ([TaskDetailsId], [TaskName], [TaskDescription], [ApplicationDetailsId], [ScheduledStartTime], [ScheduledEndTime], [ShiftDetailsId]) VALUES (8, N'Shift 2 - Feed Availability Checking', N'Shift 2 - Feed Availability Checking', 2, N'1900-01-01 15:00:00', N'1900-01-01 15:30:00', 1)
INSERT INTO [dbo].[TaskDetails] ([TaskDetailsId], [TaskName], [TaskDescription], [ApplicationDetailsId], [ScheduledStartTime], [ScheduledEndTime], [ShiftDetailsId]) VALUES (9, N'Shift 3 - Feed Availability Checking', N'Shift 3 - Feed Availability Checking', 3, N'1900-01-01 23:00:00', N'1900-01-01 23:30:00', 3)
INSERT INTO [dbo].[TaskDetails] ([TaskDetailsId], [TaskName], [TaskDescription], [ApplicationDetailsId], [ScheduledStartTime], [ScheduledEndTime], [ShiftDetailsId]) VALUES (14, N'Testing', N'Testing', 2, N'2017-09-22 20:00:00', N'2017-09-22 20:20:00', 2)
SET IDENTITY_INSERT [dbo].[TaskDetails] OFF
");
        }
        
        public override void Down()
        {
        }
    }
}
