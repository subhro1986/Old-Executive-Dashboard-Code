namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateAnnouncementTrackingDetails1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AnnouncementTrackingDetails",
                c => new
                    {
                        AnnouncementTrackingDetailsId = c.Int(nullable: false, identity: true),
                        AnnouncementDetailsId = c.Int(nullable: false),
                        AnnouncementName = c.String(nullable: false),
                        AnnouncementDescription = c.String(nullable: false),
                        ValidFrom = c.DateTime(nullable: false),
                        ValidUpto = c.DateTime(nullable: false),
                        Contact = c.String(),
                        ReadBy = c.String(),
                        ReadTime = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.AnnouncementTrackingDetailsId)
                .ForeignKey("dbo.AnnouncementDetails", t => t.AnnouncementDetailsId, cascadeDelete: true)
                .Index(t => t.AnnouncementDetailsId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AnnouncementTrackingDetails", "AnnouncementDetailsId", "dbo.AnnouncementDetails");
            DropIndex("dbo.AnnouncementTrackingDetails", new[] { "AnnouncementDetailsId" });
            DropTable("dbo.AnnouncementTrackingDetails");
        }
    }
}
