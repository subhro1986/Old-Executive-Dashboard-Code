namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateDBTables : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.AnnouncementDetails", "ValidFrom", c => c.DateTime(nullable: false));
            AlterColumn("dbo.AnnouncementDetails", "ValidUpto", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.AnnouncementDetails", "ValidUpto", c => c.DateTime());
            AlterColumn("dbo.AnnouncementDetails", "ValidFrom", c => c.DateTime());
        }
    }
}
