namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class TaskListAndMailDetails : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.MailSentDetails",
                c => new
                    {
                        MailSentDetailsId = c.Int(nullable: false, identity: true),
                        MailTo = c.String(),
                        MailCC = c.String(),
                        MailBody = c.String(),
                        MailSubject = c.String(),
                        TaskListByShiftId = c.Int(nullable: false),
                        IncidentNumber = c.String(),
                    })
                .PrimaryKey(t => t.MailSentDetailsId)
                .ForeignKey("dbo.TaskListByShifts", t => t.TaskListByShiftId, cascadeDelete: true)
                .Index(t => t.TaskListByShiftId);
            
            CreateTable(
                "dbo.TaskListByShifts",
                c => new
                    {
                        TaskListByShiftId = c.Int(nullable: false, identity: true),
                        TaskDetailsId = c.Int(nullable: false),
                        ActionedBy = c.String(),
                        ActionedTime = c.DateTime(nullable: false),
                        IsSuccess = c.Boolean(nullable: false),
                        IsException = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.TaskListByShiftId)
                .ForeignKey("dbo.TaskDetails", t => t.TaskDetailsId, cascadeDelete: true)
                .Index(t => t.TaskDetailsId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.MailSentDetails", "TaskListByShiftId", "dbo.TaskListByShifts");
            DropForeignKey("dbo.TaskListByShifts", "TaskDetailsId", "dbo.TaskDetails");
            DropIndex("dbo.TaskListByShifts", new[] { "TaskDetailsId" });
            DropIndex("dbo.MailSentDetails", new[] { "TaskListByShiftId" });
            DropTable("dbo.TaskListByShifts");
            DropTable("dbo.MailSentDetails");
        }
    }
}
