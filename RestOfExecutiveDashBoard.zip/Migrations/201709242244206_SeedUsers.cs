namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SeedUsers : DbMigration
    {
        public override void Up()
        {
            Sql(@"
INSERT INTO [dbo].[AspNetUsers] ([Id], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES (N'365b5ef7-9e22-4c9d-8913-1b8446d28227', N'Monoseej.Sinha@rbc.com', 0, N'AHcP8H6gH8Xs99MYcg/g2KjOE7Ml5vT0PmXakTkaE7yddMcNJ6Q7KxhoTt+JqwF5sw==', N'ce8bb491-41a8-4928-93c7-4033c2809b24', NULL, 0, 0, NULL, 1, 0, N'Monoseej.Sinha@rbc.com')
INSERT INTO [dbo].[AspNetUsers] ([Id], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES (N'5efb2904-f67f-4870-b0f2-78f45a55def1', N'subhro.mandal@rbc.com', 0, N'ACzvqDFRJMsFLZGnmU2S6LEBHhjvsaHuNvVEdNr2zJz+Bcxx0tMJE8Iulz2Usj/2hg==', N'21ebc730-ee26-467e-b505-c0c678e49d74', NULL, 0, 0, NULL, 1, 0, N'subhro.mandal@rbc.com')
INSERT INTO [dbo].[AspNetUsers] ([Id], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES (N'96c2acd3-1b4a-4c48-9f68-14990e850f09', N'Priyanka.Mukherjee@rbc.com', 0, N'AJp+Y15YBF4uMRY3lNJeHxFgAZwBeC/HS2L/S9A/FcsydemCI+2bUaK32CFtzbb77A==', N'455eec11-ad9c-4d5a-b124-7a4fbb81ac7b', NULL, 0, 0, NULL, 1, 0, N'Priyanka.Mukherjee@rbc.com')

INSERT INTO [dbo].[AspNetRoles] ([Id], [Name]) VALUES (N'751e4692-eac1-45fe-a936-a35003aaacf8', N'CanManageMovies')
INSERT INTO [dbo].[AspNetRoles] ([Id], [Name]) VALUES (N'b81d5b5d-e624-45b4-92ce-af4b180d81a1', N'CanManageTasks')

INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'96c2acd3-1b4a-4c48-9f68-14990e850f09', N'b81d5b5d-e624-45b4-92ce-af4b180d81a1')
INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'365b5ef7-9e22-4c9d-8913-1b8446d28227', N'b81d5b5d-e624-45b4-92ce-af4b180d81a1')


");
        }
        
        public override void Down()
        {
        }
    }
}
