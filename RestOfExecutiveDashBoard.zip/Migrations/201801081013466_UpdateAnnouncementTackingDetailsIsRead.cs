namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateAnnouncementTackingDetailsIsRead : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AnnouncementTrackingDetails", "IsRead", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.AnnouncementTrackingDetails", "IsRead");
        }
    }
}
