namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateTaskListByShift : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.TaskListByShifts", "IncidentNumber", c => c.String());
            AddColumn("dbo.TaskListByShifts", "IsMailSent", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.TaskListByShifts", "IsMailSent");
            DropColumn("dbo.TaskListByShifts", "IncidentNumber");
        }
    }
}
