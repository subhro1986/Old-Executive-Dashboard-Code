namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddMailConfigDetails : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.MailConfigDetails",
                c => new
                    {
                        MailConfigDetailsId = c.Int(nullable: false, identity: true),
                        ApplicationDetailsId = c.Int(nullable: false),
                        IncidentTypeDetailsId = c.Int(nullable: false),
                        MailTo = c.String(),
                        MailCC = c.String(),
                        Subject = c.String(),
                        Body = c.String(),
                    })
                .PrimaryKey(t => t.MailConfigDetailsId)
                .ForeignKey("dbo.ApplicationDetails", t => t.ApplicationDetailsId, cascadeDelete: true)
                .ForeignKey("dbo.IncidentTypeDetails", t => t.IncidentTypeDetailsId, cascadeDelete: true)
                .Index(t => t.ApplicationDetailsId)
                .Index(t => t.IncidentTypeDetailsId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.MailConfigDetails", "IncidentTypeDetailsId", "dbo.IncidentTypeDetails");
            DropForeignKey("dbo.MailConfigDetails", "ApplicationDetailsId", "dbo.ApplicationDetails");
            DropIndex("dbo.MailConfigDetails", new[] { "IncidentTypeDetailsId" });
            DropIndex("dbo.MailConfigDetails", new[] { "ApplicationDetailsId" });
            DropTable("dbo.MailConfigDetails");
        }
    }
}
