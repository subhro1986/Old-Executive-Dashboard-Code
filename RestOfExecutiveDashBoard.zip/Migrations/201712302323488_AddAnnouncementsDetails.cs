namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddAnnouncementsDetails : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AnnouncementDetails",
                c => new
                    {
                        AnnouncementDetailsId = c.Int(nullable: false, identity: true),
                        AnnouncementName = c.String(),
                        AnnouncementDescription = c.String(),
                        ValidFrom = c.DateTime(nullable: false),
                        ValidUpto = c.DateTime(nullable: false),
                        IsValid = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.AnnouncementDetailsId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.AnnouncementDetails");
        }
    }
}
