namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateTaskListByShiftForIncident : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.TaskListByShifts", "IncidentDescription", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.TaskListByShifts", "IncidentDescription");
        }
    }
}
