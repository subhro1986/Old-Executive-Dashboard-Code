namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ModifyTaskListByShift1 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.TaskListByShifts", "ScheduledStartTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.TaskListByShifts", "ScheduledEndTime", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.TaskListByShifts", "ScheduledEndTime", c => c.DateTime());
            AlterColumn("dbo.TaskListByShifts", "ScheduledStartTime", c => c.DateTime());
        }
    }
}
