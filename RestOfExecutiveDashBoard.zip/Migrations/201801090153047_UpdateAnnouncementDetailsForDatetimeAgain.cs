namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateAnnouncementDetailsForDatetimeAgain : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.AnnouncementDetails", "AnnouncementDescription", c => c.String());
            AlterColumn("dbo.AnnouncementDetails", "ValidFrom", c => c.DateTime());
            AlterColumn("dbo.AnnouncementDetails", "ValidUpto", c => c.DateTime());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.AnnouncementDetails", "ValidUpto", c => c.DateTime(nullable: false));
            AlterColumn("dbo.AnnouncementDetails", "ValidFrom", c => c.DateTime(nullable: false));
            AlterColumn("dbo.AnnouncementDetails", "AnnouncementDescription", c => c.String(nullable: false));
        }
    }
}
