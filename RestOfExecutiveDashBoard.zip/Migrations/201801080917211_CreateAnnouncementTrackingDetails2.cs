namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateAnnouncementTrackingDetails2 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.AnnouncementTrackingDetails", "ReadTime", c => c.DateTime());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.AnnouncementTrackingDetails", "ReadTime", c => c.DateTime(nullable: false));
        }
    }
}
