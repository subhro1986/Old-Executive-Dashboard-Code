namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateShiftWiseTaskDetails : DbMigration
    {
        public override void Up()
        {
           
        }
        
        public override void Down()
        {
            AlterColumn("dbo.TaskListByShifts", "ScheduledEndTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.TaskListByShifts", "ScheduledStartTime", c => c.DateTime(nullable: false));
        }
    }
}
