namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ModifyTaskListByShift : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.TaskListByShifts", "ActionedTime", c => c.DateTime());
            AlterColumn("dbo.TaskListByShifts", "IsSuccess", c => c.Boolean());
            AlterColumn("dbo.TaskListByShifts", "IsException", c => c.Boolean());
            AlterColumn("dbo.TaskListByShifts", "IsMailSent", c => c.Boolean());
            AlterColumn("dbo.TaskListByShifts", "ScheduledStartTime", c => c.DateTime());
            AlterColumn("dbo.TaskListByShifts", "ScheduledEndTime", c => c.DateTime());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.TaskListByShifts", "ScheduledEndTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.TaskListByShifts", "ScheduledStartTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.TaskListByShifts", "IsMailSent", c => c.Boolean(nullable: false));
            AlterColumn("dbo.TaskListByShifts", "IsException", c => c.Boolean(nullable: false));
            AlterColumn("dbo.TaskListByShifts", "IsSuccess", c => c.Boolean(nullable: false));
            AlterColumn("dbo.TaskListByShifts", "ActionedTime", c => c.DateTime(nullable: false));
        }
    }
}
