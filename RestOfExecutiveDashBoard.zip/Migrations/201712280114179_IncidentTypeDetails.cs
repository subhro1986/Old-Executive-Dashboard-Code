namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class IncidentTypeDetails : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.IncidentTypeDetails",
                c => new
                    {
                        IncidentTypeDetailsId = c.Int(nullable: false, identity: true),
                        IncidentTypeName = c.String(),
                        IncidentTypeDescription = c.String(),
                    })
                .PrimaryKey(t => t.IncidentTypeDetailsId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.IncidentTypeDetails");
        }
    }
}
