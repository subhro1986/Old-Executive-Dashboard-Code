namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ModifyMailDetails : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.MailSentDetails", "ToEmail", c => c.String(nullable: false));
            AddColumn("dbo.MailSentDetails", "EMailBody", c => c.String());
            AddColumn("dbo.MailSentDetails", "EmailSubject", c => c.String());
            AddColumn("dbo.MailSentDetails", "EmailCC", c => c.String());
            AddColumn("dbo.MailSentDetails", "EmailBCC", c => c.String());
            DropColumn("dbo.MailSentDetails", "MailTo");
            DropColumn("dbo.MailSentDetails", "MailCC");
            DropColumn("dbo.MailSentDetails", "MailBody");
            DropColumn("dbo.MailSentDetails", "MailSubject");
        }
        
        public override void Down()
        {
            AddColumn("dbo.MailSentDetails", "MailSubject", c => c.String());
            AddColumn("dbo.MailSentDetails", "MailBody", c => c.String());
            AddColumn("dbo.MailSentDetails", "MailCC", c => c.String());
            AddColumn("dbo.MailSentDetails", "MailTo", c => c.String());
            DropColumn("dbo.MailSentDetails", "EmailBCC");
            DropColumn("dbo.MailSentDetails", "EmailCC");
            DropColumn("dbo.MailSentDetails", "EmailSubject");
            DropColumn("dbo.MailSentDetails", "EMailBody");
            DropColumn("dbo.MailSentDetails", "ToEmail");
        }
    }
}
