namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateTaskListByShiftForIncidentType : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.TaskListByShifts", "IncidentTypeDetailsId", c => c.Int());
            CreateIndex("dbo.TaskListByShifts", "IncidentTypeDetailsId");
            AddForeignKey("dbo.TaskListByShifts", "IncidentTypeDetailsId", "dbo.IncidentTypeDetails", "IncidentTypeDetailsId");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.TaskListByShifts", "IncidentTypeDetailsId", "dbo.IncidentTypeDetails");
            DropIndex("dbo.TaskListByShifts", new[] { "IncidentTypeDetailsId" });
            DropColumn("dbo.TaskListByShifts", "IncidentTypeDetailsId");
        }
    }
}
