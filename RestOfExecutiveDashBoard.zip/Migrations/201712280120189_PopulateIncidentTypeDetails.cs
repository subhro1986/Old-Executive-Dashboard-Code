namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PopulateIncidentTypeDetails : DbMigration
    {
        public override void Up()
        {
            Sql("INSERT INTO IncidentTypeDetails (IncidentTypeName, IncidentTypeDescription) VALUES ('Feed Delay','Delay in Feed Arrival')");
            Sql("INSERT INTO IncidentTypeDetails (IncidentTypeName, IncidentTypeDescription) VALUES ('CPU Utilization High','CPU Utilization High')");
            Sql("INSERT INTO IncidentTypeDetails (IncidentTypeName, IncidentTypeDescription) VALUES ('Holiday Rollover','Holiday Rollover')");
            Sql("INSERT INTO IncidentTypeDetails (IncidentTypeName, IncidentTypeDescription) VALUES ('Job Unsuccessful','Job Unsuccessful')");
            Sql("INSERT INTO IncidentTypeDetails (IncidentTypeName, IncidentTypeDescription) VALUES ('Job Long Running','Job Long Running')");
        }
        
        public override void Down()
        {
        }
    }
}
