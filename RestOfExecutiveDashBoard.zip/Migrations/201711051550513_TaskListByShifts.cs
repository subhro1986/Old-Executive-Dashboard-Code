namespace ExecutiveDashboard.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class TaskListByShifts : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.TaskListByShifts", "TaskDetailsId", "dbo.TaskDetails");
            DropIndex("dbo.TaskListByShifts", new[] { "TaskDetailsId" });
            AddColumn("dbo.TaskListByShifts", "TaskName", c => c.String());
            AddColumn("dbo.TaskListByShifts", "ApplicationName", c => c.String());
            AddColumn("dbo.TaskListByShifts", "ScheduledStartTime", c => c.DateTime(nullable: false));
            AddColumn("dbo.TaskListByShifts", "ApplicationDetailsId", c => c.Int(nullable: false));
            AddColumn("dbo.TaskListByShifts", "ShiftDetailsId", c => c.Int(nullable: false));
            AddColumn("dbo.TaskListByShifts", "ScheduledEndTime", c => c.DateTime(nullable: false));
            AlterColumn("dbo.TaskListByShifts", "TaskDetailsId", c => c.Int());
            CreateIndex("dbo.TaskListByShifts", "TaskDetailsId");
            CreateIndex("dbo.TaskListByShifts", "ApplicationDetailsId");
            CreateIndex("dbo.TaskListByShifts", "ShiftDetailsId");
            AddForeignKey("dbo.TaskListByShifts", "ApplicationDetailsId", "dbo.ApplicationDetails", "ApplicationDetailsId", cascadeDelete: true);
            AddForeignKey("dbo.TaskListByShifts", "ShiftDetailsId", "dbo.ShiftDetails", "ShiftDetailsId", cascadeDelete: true);
            AddForeignKey("dbo.TaskListByShifts", "TaskDetailsId", "dbo.TaskDetails", "TaskDetailsId");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.TaskListByShifts", "TaskDetailsId", "dbo.TaskDetails");
            DropForeignKey("dbo.TaskListByShifts", "ShiftDetailsId", "dbo.ShiftDetails");
            DropForeignKey("dbo.TaskListByShifts", "ApplicationDetailsId", "dbo.ApplicationDetails");
            DropIndex("dbo.TaskListByShifts", new[] { "ShiftDetailsId" });
            DropIndex("dbo.TaskListByShifts", new[] { "ApplicationDetailsId" });
            DropIndex("dbo.TaskListByShifts", new[] { "TaskDetailsId" });
            AlterColumn("dbo.TaskListByShifts", "TaskDetailsId", c => c.Int(nullable: false));
            DropColumn("dbo.TaskListByShifts", "ScheduledEndTime");
            DropColumn("dbo.TaskListByShifts", "ShiftDetailsId");
            DropColumn("dbo.TaskListByShifts", "ApplicationDetailsId");
            DropColumn("dbo.TaskListByShifts", "ScheduledStartTime");
            DropColumn("dbo.TaskListByShifts", "ApplicationName");
            DropColumn("dbo.TaskListByShifts", "TaskName");
            CreateIndex("dbo.TaskListByShifts", "TaskDetailsId");
            AddForeignKey("dbo.TaskListByShifts", "TaskDetailsId", "dbo.TaskDetails", "TaskDetailsId", cascadeDelete: true);
        }
    }
}
