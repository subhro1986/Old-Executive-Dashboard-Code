﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ExecutiveDashboard.Dtos
{
    public class MailConfigDto
    {
        public int MailConfigDetailsId { get; set; }
        public int ApplicationDetailsId { get; set; }
        public int IncidentTypeDetailsId { get; set; }
        public string MailTo { get; set; }
        public string MailCC { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }

        public ApplicationDetailsDto ApplicationDetails { get; set; }
        public IncidentTypeDetailsDto IncidentTypeDetails { get; set; }
    }

}