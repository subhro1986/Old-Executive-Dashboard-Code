﻿using ExecutiveDashboard.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Dtos
{
    public class ApplicationDetailsDto
    {
        public int ApplicationDetailsId { get; set; }
        public string ApplicationName { get; set; }
        public string ApplicationCode { get; set; }
        public string ApplicationDescription { get; set; }
        public int ApplicationManagerDetailsId { get; set; }
        public int ApplicationStatusDetailsId { get; set; }
        public string ApplicationL2MailId { get; set; }
        public string ApplicationL3MailId { get; set; }



        public ApplicationStatusDetails ApplicationStatusDetails { get; set; }
        public ApplicationManagerDetails ApplicationManagerDetails { get; set; }
    }
}