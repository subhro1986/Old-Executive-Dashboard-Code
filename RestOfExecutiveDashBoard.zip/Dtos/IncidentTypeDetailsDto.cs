﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Dtos
{
    public class IncidentTypeDetailsDto
    {
        public int IncidentTypeDetailsId { get; set; }
        public string IncidentTypeName { get; set; }
        public string IncidentTypeDescription { get; set; }
    }
}