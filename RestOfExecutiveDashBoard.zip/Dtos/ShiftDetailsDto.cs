﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Dtos
{
    public class ShiftDetailsDto
    {
        public int ShiftDetailsId { get; set; }
        public String ShiftName { get; set; }

    }
}