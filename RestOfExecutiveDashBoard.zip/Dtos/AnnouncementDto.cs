﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ExecutiveDashboard.Dtos
{
    public class AnnouncementDto
    {
        public int AnnouncementDetailsId { get; set; }
        public string AnnouncementName { get; set; }
        public string AnnouncementDescription { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidUpto { get; set; }
        public string Contact { get; set; }
    }

}