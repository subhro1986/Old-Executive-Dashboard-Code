﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecutiveDashboard.Dtos
{
    public class TaskListByShiftsDto
    {
       
            public int TaskListByShiftId { get; set; }
            public int TaskDetailsId { get; set; }
            public string ActionedBy { get; set; }
            public DateTime ActionedTime { get; set; }
            public bool IsSuccess { get; set; }
            public bool IsException { get; set; }
            public string IncidentNumber { get; set; }
            public bool IsMailSent { get; set; }
                    public TaskDto TaskDetails { get; set; }

        
    }
}