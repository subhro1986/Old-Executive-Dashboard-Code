﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ExecutiveDashboard.Dtos
{
    public class TaskDto
    {
        public int TaskDetailsId { get; set; }
        public string TaskName { get; set; }
        public string TaskDescription { get; set; }
        public int ApplicationDetailsId { get; set; }
        public string ApplicationName { get; set; }
        public int ShiftDetailsId { get; set; }
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:hh:mm tt}", ApplyFormatInEditMode = true)]
        public DateTime ScheduledStartTime { get; set; }
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:hh:mm tt}", ApplyFormatInEditMode = true)]
        public DateTime ScheduledEndTime { get; set; }
        public ApplicationDetailsDto ApplicationDetails { get; set; }
        public ShiftDetailsDto ShiftDetails { get; set; }
    }

}