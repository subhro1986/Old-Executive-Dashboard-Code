﻿$(function () {
    $('.mvc-bootstrap-timepicker').timepicker();
});
