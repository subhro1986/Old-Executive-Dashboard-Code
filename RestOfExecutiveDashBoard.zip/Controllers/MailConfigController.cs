﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Ajax.Utilities;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.ViewModels;
using System.Data.Entity;

namespace ExecutiveDashboard.Controllers
{
    public class MailConfigController : Controller
    {
        private ApplicationDbContext _context;

        public MailConfigController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        [Authorize(Roles = RoleName.CanManageTasks)]
        public ViewResult New()
        {
            var applicationDetails = _context.ApplicationDetails.ToList();
            var incidentTypeDetails = _context.IncidentTypeDetails.ToList();

            var viewModel = new MailConfigViewModel()
            {
                ApplicationDetails = applicationDetails,
                IncidentTypeDetails = incidentTypeDetails
            };

            return View("MailConfigForm", viewModel);
        }

        public ActionResult Edit(int id)
        {
            var mail = _context.MailConfigDetails.SingleOrDefault(c => c.MailConfigDetailsId == id);

            if (mail == null)
                return HttpNotFound();

            var viewModel = new MailConfigViewModel(mail)
            {
                ApplicationDetails = _context.ApplicationDetails.ToList(),
                IncidentTypeDetails = _context.IncidentTypeDetails.ToList()
            };

            return View("MailConfigForm", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(MailConfigDetails mail)
        {
            if (!ModelState.IsValid)
            {
                var viewModel = new MailConfigViewModel(mail)
                {
                    ApplicationDetails = _context.ApplicationDetails.ToList(),
                    IncidentTypeDetails = _context.IncidentTypeDetails.ToList()
                };

                return View("MailConfigForm", viewModel);
            }
            if (mail.MailConfigDetailsId == 0)
            {
                _context.MailConfigDetails.Add(mail);
            }
            else
            {
                var mailInDb = _context.MailConfigDetails.Single(m => m.MailConfigDetailsId == mail.MailConfigDetailsId);
               
                mailInDb.ApplicationDetailsId = mail.ApplicationDetailsId;
                mailInDb.IncidentTypeDetailsId = mail.IncidentTypeDetailsId;
                mailInDb.MailTo = mail.MailTo;
                mailInDb.MailCC = mail.MailCC;
                mailInDb.Subject = mail.Subject;
                mailInDb.Body = mail.Body;
            }

            _context.SaveChanges();

            return RedirectToAction("Index", "MailConfig");
        }


        public ViewResult Index()
        {
            var mails = _context.MailConfigDetails
                                .Include(m => m.ApplicationDetails)
                                .Include(m => m.IncidentTypeDetails)
                                .ToList();
            if (User.IsInRole(RoleName.CanManageTasks))
            {
                return View("Index", mails);
            }
            else
            {
                return View("readOnlyTasklist", mails);

            }


        }

        public ActionResult Details(int id)
        {
            var mails = _context.MailConfigDetails
                                .Include(m => m.ApplicationDetails)
                                .Include(m => m.IncidentTypeDetails)
                                .SingleOrDefault(m => m.MailConfigDetailsId == id);


            return View(mails);
        }

        public ActionResult Compose(int appId, int incTypeId)
        {
            var mailConfig = _context.MailConfigDetails.Where(m => m.ApplicationDetailsId == appId)
                                                       .Where(m => m.IncidentTypeDetailsId == incTypeId);

            if (mailConfig == null)
                return HttpNotFound();

            //var viewModel = new MailConfigViewModel(mail)
            //{
            //    ApplicationDetails = _context.ApplicationDetails.ToList(),
            //    IncidentTypeDetails = _context.IncidentTypeDetails.ToList()
            //};

            return View("SendMail", mailConfig);
        }




    }
}

