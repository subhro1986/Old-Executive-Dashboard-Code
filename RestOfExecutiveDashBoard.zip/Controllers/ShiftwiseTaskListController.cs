﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Ajax.Utilities;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.ViewModels;
using System.Data.Entity;

namespace ExecutiveDashboard.Controllers
{
    public class ShiftwiseTaskListController : Controller
    {
        private ApplicationDbContext _context;

        public ShiftwiseTaskListController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        public ViewResult Index(int id)
        {
            var tasks = _context.TaskListByShift
                    .Include(t => t.ApplicationDetails)
                    .Include(t => t.ShiftDetails)
                    .Where(t => t.ShiftDetailsId == id)
                    .Where(t => t.TaskDate >= DateTime.Today)
                    .Where(t => t.IsSuccess == null)
                    .Where(t => t.IsException == null)
                    .OrderByDescending(t => t.ScheduledStartTime)
                    .ToList();

            return View("ShiftwiseTaskList", tasks);

        }

        public ActionResult SaveSuccess(int id)
        {

            var task = _context.TaskListByShift.SingleOrDefault(c => c.TaskListByShiftId == id);
            if (task == null)
                return HttpNotFound();

            if (task.TaskListByShiftId != 0)
            {
                var taskInDb = _context.TaskListByShift.Single(t => t.TaskListByShiftId == task.TaskListByShiftId);
                taskInDb.TaskDetailsId = task.TaskDetailsId;
                taskInDb.ActionedBy = User.Identity.Name;
                taskInDb.ActionedTime = DateTime.Now;
                taskInDb.IsSuccess = true;
                taskInDb.IsException = false;
                taskInDb.IsMailSent = false;
                taskInDb.TaskName = task.TaskName;
                taskInDb.ScheduledStartTime = task.ScheduledStartTime;
                taskInDb.ScheduledEndTime = task.ScheduledEndTime;
                taskInDb.ApplicationDetailsId = task.ApplicationDetailsId;
                taskInDb.ShiftDetailsId = task.ShiftDetailsId;

            }

            _context.SaveChanges();

            return Index(task.ShiftDetailsId);

        }

        public ActionResult SaveException(int id)
        {

            var task = _context.TaskListByShift.Include(t => t.ApplicationDetails)
                                               .Include(t => t.ShiftDetails)
                                               .SingleOrDefault(c => c.TaskListByShiftId == id); 
            var taskInDb = _context.TaskListByShift.Single(t => t.TaskListByShiftId == task.TaskListByShiftId);
            if (task == null)
                return HttpNotFound();

            if (task.TaskListByShiftId != 0)
            {
                                
                taskInDb.TaskDetailsId = task.TaskDetailsId;
                taskInDb.ActionedBy = User.Identity.Name;
                taskInDb.ActionedTime = DateTime.Now;
                taskInDb.IsSuccess = false;
                taskInDb.IsException = true;
                taskInDb.IsMailSent = false;
                taskInDb.TaskName = task.TaskName;
                taskInDb.ScheduledStartTime = task.ScheduledStartTime;
                taskInDb.ScheduledEndTime = task.ScheduledEndTime;
                taskInDb.ApplicationDetailsId = task.ApplicationDetailsId;
                taskInDb.ApplicationName = task.ApplicationDetails.ApplicationName;
                taskInDb.ShiftDetailsId = task.ShiftDetailsId;
                taskInDb.IncidentTitle = task.ApplicationDetails.ApplicationName + " || " + "PROD || Exception in " + task.TaskName;

            }

            _context.SaveChanges();

            //return UpdateIncidentDetails(task);

            return RedirectToAction("NewIncidentForm", "Incident", new { id = taskInDb.TaskListByShiftId});



        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateIncidentDetails(TaskListByShift task)
        {

            if (task.TaskListByShiftId != 0)
            {
                var taskInDb = _context.TaskListByShift.Single(t => t.TaskListByShiftId == task.TaskListByShiftId);
                taskInDb.TaskName = task.TaskName;
                taskInDb.ApplicationName = task.ApplicationName;
                taskInDb.IncidentNumber = task.IncidentNumber;
                taskInDb.IncidentDescription = task.IncidentDescription;
            }

            _context.SaveChanges();

            return RedirectToAction("Index", "Task");
        }

    }
}

