﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Ajax.Utilities;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.ViewModels;
using System.Data.Entity;

namespace ExecutiveDashboard.Controllers
{
    public class IncidentController : Controller
    {
        private ApplicationDbContext _context;

        public IncidentController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        public ViewResult Index(int id)
        {
            var task = _context.TaskListByShift.SingleOrDefault(c => c.TaskListByShiftId == id);


            return View();

        }

        public ActionResult  NewIncidentForm(int id)
        {
            var incident = _context.TaskListByShift
                                                   .Include(i => i.IncidentTypeDetails)
                                                   .SingleOrDefault(i => i.TaskListByShiftId == id);

            if (incident == null)
                return HttpNotFound();

            var viewModel = new TaskListByShiftViewModel(incident)
            {
                ApplicationDetails = _context.ApplicationDetails.ToList(),
                IncidentTypeDetails = _context.IncidentTypeDetails.ToList()

            };

            return View("IncidentForm", viewModel);
            //return View("IncidentForm", incident);

        }                    

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(TaskListByShift incident)
        {
            //    if (!ModelState.IsValid)
            //    {
            //        var viewModel = new TaskListByShiftViewModel(incident)
            //        {
            //            ApplicationDetails = _context.ApplicationDetails.ToList(),
            //            IncidentTypeDetails = _context.IncidentTypeDetails.ToList()
            //        };

            //        return View("IncidentForm", viewModel);

            //}
            var incidentInDb = _context.TaskListByShift.Single(i => i.TaskListByShiftId == incident.TaskListByShiftId);
            if (incident.TaskListByShiftId != 0)
           
            {
                
                incidentInDb.IncidentTitle = incident.IncidentTitle;
                incidentInDb.IncidentNumber = incident.IncidentNumber;
                incidentInDb.IncidentTypeDetailsId = incident.IncidentTypeDetailsId;
                incidentInDb.ApplicationDetailsId = incident.ApplicationDetailsId;
                incidentInDb.IncidentDescription = incident.IncidentDescription;
                incidentInDb.IncidentStartTime = incident.IncidentStartTime; 
                incidentInDb.IncidentEndTime = incident.IncidentEndTime; 
                
            }

            _context.SaveChanges();

            var mailConfig = _context.MailConfigDetails.SingleOrDefault(m => m.ApplicationDetailsId == incident.ApplicationDetailsId && m.IncidentTypeDetailsId == incident.IncidentTypeDetailsId);
                                                       

            if (mailConfig == null)
                return HttpNotFound();

            //var viewModel = new MailConfigViewModel(mail)
            //{
            //    ApplicationDetails = _context.ApplicationDetails.ToList(),
            //    IncidentTypeDetails = _context.IncidentTypeDetails.ToList()
            //};

            return View("SendMail", mailConfig);

            //return RedirectToAction("Compose", "MailConfig", new { ApplicationDetailsId = incident.ApplicationDetailsId, IncidentTypeDetailsId = incident.IncidentTypeDetailsId });
            //return View("SendMail", incident);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SearchIncident(TaskListByShift incident)
        {
            //    if (!ModelState.IsValid)
            //    {
            //        var viewModel = new TaskListByShiftViewModel(incident)
            //        {
            //            ApplicationDetails = _context.ApplicationDetails.ToList(),
            //            IncidentTypeDetails = _context.IncidentTypeDetails.ToList()
            //        };

            //        return View("IncidentForm", viewModel);

            //}
            var incidentInDb = _context.TaskListByShift
                                                      .Include(t => t.ApplicationDetails)
                                                      .Include(t => t.IncidentTypeDetails)
                                                      .Where(t => t.ApplicationDetailsId == incident.ApplicationDetailsId)
                                                      .Where(t=> t.IncidentTypeDetailsId == incident.IncidentTypeDetailsId)
                                                      .Where(t=> t.IncidentStartTime >= incident.IncidentStartTime)
                                                      .Where(t=> t.IncidentEndTime <=incident.IncidentEndTime)
                                                      .ToList();
            

            _context.SaveChanges();

            //var mailConfig = _context.MailConfigDetails.SingleOrDefault(m => m.ApplicationDetailsId == incident.ApplicationDetailsId && m.IncidentTypeDetailsId == incident.IncidentTypeDetailsId);


            //if (mailConfig == null)
            //    return HttpNotFound();

            //var viewModel = new MailConfigViewModel(mail)
            //{
            //    ApplicationDetails = _context.ApplicationDetails.ToList(),
            //    IncidentTypeDetails = _context.IncidentTypeDetails.ToList()
            //};

            return View("SearchIncident", incidentInDb);

            //return RedirectToAction("Compose", "MailConfig", new { ApplicationDetailsId = incident.ApplicationDetailsId, IncidentTypeDetailsId = incident.IncidentTypeDetailsId });
            //return View("SendMail", incident);
        }
    }
}