﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Ajax.Utilities;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.ViewModels;
using System.Data.Entity;

namespace ExecutiveDashboard.Controllers
{
    public class ShiftController : Controller
    {
        private ApplicationDbContext _context;

        public ShiftController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        //[Authorize(Roles = RoleName.CanManageTasks)]
        //public ViewResult New()
        //{
        //    var applicationDetails = _context.ApplicationDetails.ToList();
        //    var shiftDetails = _context.ShiftDetails.ToList();

        //    var viewModel = new TaskFormViewModel()
        //    {
        //        ApplicationDetails = applicationDetails,
        //        ShiftDetails = shiftDetails
        //    };

        //    return View("TaskForm", viewModel);
        //}

        //public ActionResult Edit(int id)
        //{
        //    var task = _context.TaskDetails.SingleOrDefault(c => c.TaskDetailsId == id);

        //    if (task == null)
        //        return HttpNotFound();

        //    var viewModel = new TaskFormViewModel(task)
        //    {
        //        ApplicationDetails = _context.ApplicationDetails.ToList(),
        //        ShiftDetails = _context.ShiftDetails.ToList()
        //    };

        //    return View("TaskForm", viewModel);
        //}

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Save(TaskDetails task)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        var viewModel = new TaskFormViewModel(task)
        //        {
        //            ApplicationDetails = _context.ApplicationDetails.ToList(),
        //            ShiftDetails = _context.ShiftDetails.ToList()
        //        };

        //        return View("TaskForm", viewModel);
        //    }
        //    if (task.TaskDetailsId == 0)
        //    {
        //        //task.DateAdded = DateTime.Now;
        //        _context.TaskDetails.Add(task);
        //    }
        //    else
        //    {
        //        var taskInDb = _context.TaskDetails.Single(t => t.TaskDetailsId == task.TaskDetailsId);
        //        taskInDb.TaskName = task.TaskName;
        //        taskInDb.TaskDescription = task.TaskDescription;
        //        taskInDb.ApplicationDetailsId = task.ApplicationDetailsId;
        //        taskInDb.ShiftDetailsId = task.ShiftDetailsId;
        //        taskInDb.ScheduledStartTime = task.ScheduledStartTime;
        //        taskInDb.ScheduledEndTime = task.ScheduledEndTime;
        //    }

        //    _context.SaveChanges();

        //    return RedirectToAction("Index", "Task");
        //}


        public ViewResult Index()
        {
            var announcements = _context.AnnouncementTrackingDetails.Where (a => a.IsRead == false).ToList();
            //var shifts = _context.ShiftDetails.ToList();

            return View("Index", announcements);

        }

        public ActionResult SaveAnnouncement(int id)
        {

            var announcement = _context.AnnouncementTrackingDetails.SingleOrDefault(a => a.AnnouncementTrackingDetailsId == id);
            if (announcement == null)
                return HttpNotFound();

            if (announcement.AnnouncementDetailsId != 0)
            {
                var announcementInDb = _context.AnnouncementTrackingDetails.Single(t => t.AnnouncementTrackingDetailsId == announcement.AnnouncementTrackingDetailsId);
                announcementInDb.AnnouncementDetailsId = announcement.AnnouncementDetailsId;
                announcementInDb.ReadBy = User.Identity.Name;
                announcementInDb.ReadTime = DateTime.Now;
                announcementInDb.AnnouncementName = announcement.AnnouncementName;
                announcementInDb.AnnouncementDescription = announcement.AnnouncementDescription;
                announcementInDb.Contact = announcement.Contact;
                announcementInDb.ValidFrom = announcement.ValidFrom;
                announcementInDb.ValidUpto = announcement.ValidUpto;
                announcementInDb.IsRead = true;
               
            }

            _context.SaveChanges();

            return Index();

        }


        //public ViewResult Index()
        //{
        //    var shifts = _context.ShiftDetails.ToList();

        //    return View("Index", shifts);
        //}

        //public ActionResult Details(int id)
        //{
        //    var tasks = _context.TaskDetails
        //                        .Include(t => t.ApplicationDetails)
        //                        .Include(t => t.ShiftDetails)
        //                        .SingleOrDefault(t => t.TaskDetailsId == id);


        //    return View(tasks);
        //}




    }
}

