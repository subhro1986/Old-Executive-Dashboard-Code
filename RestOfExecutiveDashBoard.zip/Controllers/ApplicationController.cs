﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Ajax.Utilities;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.ViewModels;
using System.Data.Entity;

namespace ExecutiveDashboard.Controllers
{
    public class ApplicationController : Controller
    {
        private ApplicationDbContext _context;

        public ApplicationController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        [Authorize(Roles = RoleName.CanManageTasks)]
        public ViewResult New()
        {
            var applicationManagerDetails = _context.ApplicationManagerDetails.ToList();
            var applicationStatusDetails = _context.ApplicationStatusDetails.ToList();

            var viewModel = new ApplicationFormViewModel()
            {
                ApplicationManagerDetails = applicationManagerDetails,
                ApplicationStatusDetails = applicationStatusDetails
            };

            return View("ApplicationForm", viewModel);
        }

        public ActionResult Edit(int id)
        {
            var app = _context.ApplicationDetails.SingleOrDefault(a => a.ApplicationDetailsId == id);

            if (app == null)
                return HttpNotFound();

            var viewModel = new ApplicationFormViewModel(app)
            {
                ApplicationManagerDetails = _context.ApplicationManagerDetails.ToList(),
                ApplicationStatusDetails = _context.ApplicationStatusDetails.ToList()
            };

            return View("ApplicationForm", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(ApplicationDetails app)
        {
            if (!ModelState.IsValid)
            {
                var viewModel = new ApplicationFormViewModel(app)
                {
                    ApplicationManagerDetails = _context.ApplicationManagerDetails.ToList(),
                    ApplicationStatusDetails = _context.ApplicationStatusDetails.ToList()
                };

                return View("ApplicationForm", viewModel);
            }
            if (app.ApplicationDetailsId == 0)
            {
                //task.DateAdded = DateTime.Now;
                _context.ApplicationDetails.Add(app);
            }
            else
            {
                var appInDb = _context.ApplicationDetails.Single(a => a.ApplicationDetailsId == app.ApplicationDetailsId);
                appInDb.ApplicationName = app.ApplicationName;
                appInDb.ApplicationCode = app.ApplicationCode;
                appInDb.ApplicationDescription = app.ApplicationDescription;
                appInDb.ApplicationManagerDetailsId = app.ApplicationManagerDetailsId;
                appInDb.ApplicationStatusDetailsId = app.ApplicationStatusDetailsId;
                appInDb.ApplicationL2MailId = app.ApplicationL2MailId;
                appInDb.ApplicationL3MailId = app.ApplicationL3MailId;
            }

            _context.SaveChanges();

            return RedirectToAction("Index", "Application");
        }


        public ViewResult Index()
        {
            var apps = _context.ApplicationDetails
                                .Include(t => t.ApplicationManagerDetails)
                                .Include(t => t.ApplicationStatusDetails)
                                .ToList();
            if (User.IsInRole(RoleName.CanManageTasks))
            {
                return View("Index", apps);
            }
            else
            {
                return View("readOnlyTasklist", apps);

            }


        }

        public ActionResult Details(int id)
        {
            var apps = _context.ApplicationDetails
                                .Include(t => t.ApplicationManagerDetails)
                                .Include(t => t.ApplicationStatusDetails)
                                .SingleOrDefault(t => t.ApplicationDetailsId == id);


            return View(apps);
        }




    }
}

