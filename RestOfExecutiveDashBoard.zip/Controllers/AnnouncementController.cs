﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExecutiveDashboard.Models;

namespace ExecutiveDashboard.Controllers
{
    public class AnnouncementController : Controller
    {
        private ApplicationDbContext _context;

        public AnnouncementController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        [Authorize(Roles = RoleName.CanManageTasks)]
        public ViewResult New()
        {
            //var applicationDetails = _context.ApplicationDetails.ToList();
            //var shiftDetails = _context.ShiftDetails.ToList();

            //var viewModel = new TaskFormViewModel()
            //{
            //    ApplicationDetails = applicationDetails,
            //    ShiftDetails = shiftDetails
            //};
            var announcement = new AnnouncementDetails();

            return View("AnnouncementForm", announcement);
        }

        public ActionResult Edit(int id)
        {
            var announcement = _context.AnnouncementDetails.SingleOrDefault(a => a.AnnouncementDetailsId == id);

            if (announcement == null)
                return HttpNotFound();

            //var viewModel = new AnnouncementFormViewModel(announcement)
            //{
            //    ApplicationDetails = _context.ApplicationDetails.ToList(),
            //    ShiftDetails = _context.ShiftDetails.ToList()
            //};

            return View("AnnouncementForm", announcement);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(AnnouncementDetails announcement)
        {
            if (!ModelState.IsValid)
            {
                //var viewModel = new AnnouncementFormViewModel(task)
                //{
                //    ApplicationDetails = _context.ApplicationDetails.ToList(),
                //    ShiftDetails = _context.ShiftDetails.ToList()
                //};

                return View("AnnouncementForm", announcement);
            }
            if (announcement.AnnouncementDetailsId == 0)
            {
                _context.AnnouncementDetails.Add(announcement);
            }
            else
            {
                var announcementInDb = _context.AnnouncementDetails.Single(t => t.AnnouncementDetailsId == announcement.AnnouncementDetailsId);
                announcementInDb.AnnouncementName = announcement.AnnouncementName;
                announcementInDb.AnnouncementDescription = announcement.AnnouncementDescription;
                announcementInDb.ValidFrom = announcement.ValidFrom;
                announcementInDb.ValidUpto = announcement.ValidUpto;
                announcementInDb.Contact = announcement.Contact;
            }

            _context.SaveChanges();

            return RedirectToAction("Index", "Announcement");
        }


        public ViewResult Index()
        {
            var announcements = _context.AnnouncementDetails.ToList();
            if (User.IsInRole(RoleName.CanManageTasks))
            {
                return View("Index", announcements);
            }
            else
            {
                return View("readOnlyTasklist", announcements);

            }


        }

        public ActionResult Details(int id)
        {
            var announcements = _context.AnnouncementDetails.SingleOrDefault(a => a.AnnouncementDetailsId == id);


            return View(announcements);
        }
    }
}