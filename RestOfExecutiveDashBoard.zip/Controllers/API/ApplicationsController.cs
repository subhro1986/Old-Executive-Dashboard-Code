﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Data.Entity;
using AutoMapper;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.Dtos;

namespace ExecutiveDashboard.Controllers.Api
{
    public class ApplicationsController : ApiController
    {
        private ApplicationDbContext _context;

        public ApplicationsController()
        {
            _context = new ApplicationDbContext();
        }
        
        // GET /api/tasks
        public IEnumerable<ApplicationDetailsDto> GetApplications()
        {
            return _context.ApplicationDetails
                .Include(t => t.ApplicationManagerDetails)
                .Include(t => t.ApplicationStatusDetails)
                .ToList()
                .Select(Mapper.Map<ApplicationDetails, ApplicationDetailsDto>);
            
        }

        public IHttpActionResult GetApplication(int id)
        {
            var app = _context.ApplicationDetails.SingleOrDefault(a => a.ApplicationDetailsId == id);

            if (app == null)
                return NotFound();
            return Ok(Mapper.Map<ApplicationDetails, ApplicationDetailsDto>(app));
        }

        [HttpPost]
        public IHttpActionResult CreateApplication(ApplicationDetailsDto appDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var app = Mapper.Map<ApplicationDetailsDto, ApplicationDetails>(appDto);
            _context.ApplicationDetails.Add(app);
            _context.SaveChanges();

            appDto.ApplicationDetailsId = app.ApplicationDetailsId;
            return Created(new Uri(Request.RequestUri + "/" + app.ApplicationDetailsId), appDto);
        }

        [HttpPut]
        public IHttpActionResult UpdateTask(int id, ApplicationDetailsDto appDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var appInDb = _context.ApplicationDetails.SingleOrDefault(t => t.ApplicationDetailsId == id);

            if (appInDb == null)
                return NotFound();

            Mapper.Map(appDto, appInDb);

            _context.SaveChanges();

            return Ok();
        }

        [HttpDelete]
        public IHttpActionResult DeleteTask(int id)
        {
            var appInDb = _context.ApplicationDetails.SingleOrDefault(t => t.ApplicationDetailsId == id);

            if (appInDb == null)
                return NotFound();
            _context.ApplicationDetails.Remove(appInDb);
            _context.SaveChanges();

            return Ok();
        }
    }
}
