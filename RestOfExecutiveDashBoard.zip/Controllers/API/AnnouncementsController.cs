﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Data.Entity;
using AutoMapper;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.Dtos;

namespace ExecutiveDashboard.Controllers.Api
{
    public class AnnouncementsController : ApiController
    {
        private ApplicationDbContext _context;

        public AnnouncementsController()
        {
            _context = new ApplicationDbContext();
        }
        
        // GET /api/tasks
        public IEnumerable<AnnouncementDto> GetAnnouncements()
        {
            return _context.AnnouncementDetails.ToList()
                .Select(Mapper.Map<AnnouncementDetails, AnnouncementDto>);
            
        }

        public IHttpActionResult GetAnnouncement(int id)
        {
            var announcement = _context.AnnouncementDetails.SingleOrDefault(t => t.AnnouncementDetailsId == id);

            if (announcement == null)
                return NotFound();
            return Ok(Mapper.Map<AnnouncementDetails, AnnouncementDto>(announcement));
        }

        [HttpPost]
        public IHttpActionResult CreateAnnouncement(AnnouncementDto announcementDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var announcement = Mapper.Map<AnnouncementDto, AnnouncementDetails>(announcementDto);
            _context.AnnouncementDetails.Add(announcement);
            _context.SaveChanges();

            announcementDto.AnnouncementDetailsId = announcement.AnnouncementDetailsId;
            return Created(new Uri(Request.RequestUri + "/" + announcement.AnnouncementDetailsId), announcementDto);
        }

        [HttpPut]
        public IHttpActionResult UpdateAnnouncement(int id, AnnouncementDto announcementDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var announcementInDb = _context.AnnouncementDetails.SingleOrDefault(t => t.AnnouncementDetailsId == id);

            if (announcementInDb == null)
                return NotFound();

            Mapper.Map(announcementDto, announcementInDb);

            _context.SaveChanges();

            return Ok();
        }

        [HttpDelete]
        public IHttpActionResult DeleteAnnouncement(int id)
        {
            var announcementInDb = _context.AnnouncementDetails.SingleOrDefault(t => t.AnnouncementDetailsId == id);

            if (announcementInDb == null)
                return NotFound();
            _context.AnnouncementDetails.Remove(announcementInDb);
            _context.SaveChanges();

            return Ok();
        }
    }
}
