﻿  using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Data.Entity;
using AutoMapper;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.Dtos;

namespace ExecutiveDashboard.Controllers.Api
{
    public class ShiftsController : ApiController
    {
        private ApplicationDbContext _context;

        public ShiftsController()
        {
            _context = new ApplicationDbContext();
        }

        // GET /api/tasks
        public IEnumerable<TaskDto> GetTasks(int id)
        {
            return _context.TaskDetails
                .Include(t => t.ApplicationDetails)
                .Include(t => t.ShiftDetails)
                .Where(t => t.ShiftDetailsId == id)
                .ToList()
                .Select(Mapper.Map<TaskDetails, TaskDto>);

        }

        //public IHttpActionResult GetTasksByShift(int id)
        //{
        //    var task = _context.TaskDetails.Where(t => t.ShiftDetailsId == id).ToList();

        //    if (task == null)
        //        return NotFound();
        //    return Ok(Mapper.Map<TaskDetails, TaskDto>(task));
        //}

        [HttpPost]
        public IHttpActionResult CreateTask(TaskListByShiftsDto taskByShiftDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var taskByShift = Mapper.Map<TaskListByShiftsDto, TaskListByShift>(taskByShiftDto);
            _context.TaskListByShift.Add(taskByShift);
            _context.SaveChanges();

            taskByShiftDto.TaskListByShiftId = taskByShift.TaskListByShiftId;
            return Created(new Uri(Request.RequestUri + "/" + taskByShift.TaskListByShiftId), taskByShiftDto);
        }

        [HttpPut]
        public IHttpActionResult UpdateTask(int id, TaskDto taskDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var taskInDb = _context.TaskDetails.SingleOrDefault(t => t.TaskDetailsId == id);

            if (taskInDb == null)
                return NotFound();

            Mapper.Map(taskDto, taskInDb);

            _context.SaveChanges();

            return Ok();
        }

        [HttpDelete]
        public IHttpActionResult DeleteTask(int id)
        {
            var taskInDb = _context.TaskDetails.SingleOrDefault(t => t.TaskDetailsId == id);

            if (taskInDb == null)
                return NotFound();
            _context.TaskDetails.Remove(taskInDb);
            _context.SaveChanges();

            return Ok();
        }
    }
}
