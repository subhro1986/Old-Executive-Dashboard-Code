﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Data.Entity;
using AutoMapper;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.Dtos;

namespace ExecutiveDashboard.Controllers.Api
{
    public class TasksController : ApiController
    {
        private ApplicationDbContext _context;

        public TasksController()
        {
            _context = new ApplicationDbContext();
        }
        
        // GET /api/tasks
        public IEnumerable<TaskDto> GetTasks()
        {
            return _context.TaskDetails
                .Include(t => t.ApplicationDetails)
                .Include(t => t.ShiftDetails)
                .ToList()
                .Select(Mapper.Map<TaskDetails, TaskDto>);
            
        }

        public IHttpActionResult GetTask(int id)
        {
            var task = _context.TaskDetails.SingleOrDefault(t => t.TaskDetailsId == id);

            if (task == null)
                return NotFound();
            return Ok(Mapper.Map<TaskDetails, TaskDto>(task));
        }

        [HttpPost]
        public IHttpActionResult CreateTask(TaskDto taskDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var task = Mapper.Map<TaskDto, TaskDetails>(taskDto);
            _context.TaskDetails.Add(task);
            _context.SaveChanges();

            taskDto.TaskDetailsId = task.TaskDetailsId;
            return Created(new Uri(Request.RequestUri + "/" + task.TaskDetailsId), taskDto);
        }

        [HttpPut]
        public IHttpActionResult UpdateTask(int id, TaskDto taskDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var taskInDb = _context.TaskDetails.SingleOrDefault(t => t.TaskDetailsId == id);

            if (taskInDb == null)
                return NotFound();

            Mapper.Map(taskDto, taskInDb);

            _context.SaveChanges();

            return Ok();
        }

        [HttpDelete]
        public IHttpActionResult DeleteTask(int id)
        {
            var taskInDb = _context.TaskDetails.SingleOrDefault(t => t.TaskDetailsId == id);

            if (taskInDb == null)
                return NotFound();
            _context.TaskDetails.Remove(taskInDb);
            _context.SaveChanges();

            return Ok();
        }
    }
}
