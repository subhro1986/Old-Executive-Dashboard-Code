﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Data.Entity;
using AutoMapper;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.Dtos;

namespace ExecutiveDashboard.Controllers.Api
{
    public class MailsController : ApiController
    {
        private ApplicationDbContext _context;

        public MailsController()
        {
            _context = new ApplicationDbContext();
        }
        
        // GET /api/tasks
        public IEnumerable<MailConfigDto> GetMailConfigs()
        {
            return _context.MailConfigDetails
                                             .Include(t => t.ApplicationDetails)
                                             .Include(t => t.IncidentTypeDetails)
                                             .ToList()
                                             .Select(Mapper.Map<MailConfigDetails, MailConfigDto>);
            
        }

        public IHttpActionResult GetMailConfig(int id)
        {
            var mail = _context.MailConfigDetails.SingleOrDefault(t => t.MailConfigDetailsId == id);

            if (mail == null)
                return NotFound();
            return Ok(Mapper.Map<MailConfigDetails, MailConfigDto>(mail));
        }

        [HttpPost]
        public IHttpActionResult CreateMailConfig(MailConfigDto mailDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var mail = Mapper.Map<MailConfigDto, MailConfigDetails>(mailDto);
            _context.MailConfigDetails.Add(mail);
            _context.SaveChanges();

            mailDto.MailConfigDetailsId = mail.MailConfigDetailsId;
            return Created(new Uri(Request.RequestUri + "/" + mail.MailConfigDetailsId), mailDto);
        }

        [HttpPut]
        public IHttpActionResult UpdateMailConfig(int id, TaskDto mailDto)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var mailInDb = _context.MailConfigDetails.SingleOrDefault(t => t.MailConfigDetailsId == id);

            if (mailInDb == null)
                return NotFound();

            Mapper.Map(mailDto, mailInDb);

            _context.SaveChanges();

            return Ok();
        }

        [HttpDelete]
        public IHttpActionResult DeleteMailConfig(int id)
        {
            var mailInDb = _context.MailConfigDetails.SingleOrDefault(t => t.MailConfigDetailsId == id);

            if (mailInDb == null)
                return NotFound();
            _context.MailConfigDetails.Remove(mailInDb);
            _context.SaveChanges();

            return Ok();
        }
    }
}
