﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Ajax.Utilities;
using ExecutiveDashboard.Models;
using ExecutiveDashboard.ViewModels;
using System.Data.Entity;

namespace ExecutiveDashboard.Controllers
{
    public class TaskController : Controller
    {
        private ApplicationDbContext _context;

        public TaskController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        [Authorize(Roles = RoleName.CanManageTasks)]
        public ViewResult New()
        {
            var applicationDetails = _context.ApplicationDetails.ToList();
            var shiftDetails = _context.ShiftDetails.ToList();

            var viewModel = new TaskFormViewModel()
            {
                ApplicationDetails = applicationDetails,
                ShiftDetails = shiftDetails
            };

            return View("TaskForm", viewModel);
        }

        public ActionResult Edit(int id)
        {
            var task = _context.TaskDetails.SingleOrDefault(c => c.TaskDetailsId == id);

            if (task == null)
                return HttpNotFound();

            var viewModel = new TaskFormViewModel(task)
            {
                ApplicationDetails = _context.ApplicationDetails.ToList(),
                ShiftDetails = _context.ShiftDetails.ToList()
            };

            return View("TaskForm", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(TaskDetails task)
        {
            if (!ModelState.IsValid)
            {
                var viewModel = new TaskFormViewModel(task)
                {
                    ApplicationDetails = _context.ApplicationDetails.ToList(),
                    ShiftDetails = _context.ShiftDetails.ToList()
                };

                return View("TaskForm", viewModel);
            }
            if (task.TaskDetailsId == 0)
            {
                _context.TaskDetails.Add(task);
            }
            else
            {
                var taskInDb = _context.TaskDetails.Single(t => t.TaskDetailsId == task.TaskDetailsId);
                taskInDb.TaskName = task.TaskName;
                taskInDb.TaskDescription = task.TaskDescription;
                taskInDb.ApplicationDetailsId = task.ApplicationDetailsId;
                taskInDb.ApplicationName = task.ApplicationName;
                taskInDb.ShiftDetailsId = task.ShiftDetailsId;
                taskInDb.ScheduledStartTime = task.ScheduledStartTime;
                taskInDb.ScheduledEndTime = task.ScheduledEndTime;
            }

            _context.SaveChanges();

            return RedirectToAction("Index", "Task");
        }


        public ViewResult Index()
        {
            var tasks = _context.TaskDetails
                                .Include(t => t.ApplicationDetails)
                                .Include(t => t.ShiftDetails)
                                .ToList();
            if (User.IsInRole(RoleName.CanManageTasks))
            {
                return View("Index", tasks);
            }
            else
            {
                return View("readOnlyTasklist", tasks);

            }


        }

        public ActionResult Details(int id)
        {
            var tasks = _context.TaskDetails
                                .Include(t => t.ApplicationDetails)
                                .Include(t => t.ShiftDetails)
                                .SingleOrDefault(t => t.TaskDetailsId == id);


            return View(tasks);
        }




    }
}

